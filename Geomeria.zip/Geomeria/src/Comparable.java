
public interface Comparable {
	boolean compareArea(Object o);
	boolean comparePerim(Object o);
}

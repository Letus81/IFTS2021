
public abstract class Forma implements Comparable {
	int lato;
	
	abstract double area();
	abstract double perimetro();
	
	void finale() {
		System.out.println("invoco il metodo finale");
	}
	
	public boolean compareArea(Object o) {
		if(o instanceof Forma) {
			Forma no = (Forma) o;
			
			if(this.area() == no.area())
				return true;
			
			else
				return false;
		}
		
		return false;
	}
	
	public boolean comparePerim(Object o) {
		if(o instanceof Forma) {
			Forma no = (Forma)o;
			
			if(this.perimetro() == no.perimetro())
				return true;
			
			else
				return false;
		}
		
		return false;
	}

}

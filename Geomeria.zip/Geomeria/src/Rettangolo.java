
public class Rettangolo extends Forma {
	int altezza;
	
	Rettangolo(int b, int h) {
		lato = b;
		altezza = h;
	}
	
	double area() {
		return lato * altezza;
	}
	
	double perimetro() {
		return 2 * lato + 2 * altezza;
	}
}


public class Triangolo extends Forma {
	int altezza;

	public Triangolo(int l, int h) {
		lato = l;
		altezza = h;
	}
	
	double area() {
		return (lato * altezza) / 2;
	}
	
	public double perimetro() {
		return 3 * lato;
	}
}

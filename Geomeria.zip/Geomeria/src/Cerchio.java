
public class Cerchio extends Forma {
	public Cerchio(int r) {
		lato = r;
	}
	
	//OVERRIDE significa RIDEFINIRE il corpo del metodo, metodo definito nella classe base
	public double area() { //corpo del metodo
		return Math.PI * lato * lato;
	}
	
	public double perimetro() {
		return 2* Math.PI * lato;
	}
	
	void saluto() {
		System.out.println("ciao");
	}
	
	//overload del metodo saluto, i due metodi saluto sono all'interno della
	//stessa classe
	void saluto(String n) {
		System.out.println("ciao " + n);
	}
}

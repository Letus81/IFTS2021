public class Quadrato extends Forma {
	public Quadrato(int l) {
		lato = l;
	}
	
	public double area() {
		return lato * lato;
	}
	
	public double perimetro() {
		return 4 * lato;
	}
}

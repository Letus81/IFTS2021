
public class Principale {

	public static void main(String[] args) {		
		Forma t = new Triangolo(5, 3);
		System.out.println("area triangolo t = " + t.area());
		System.out.println("perimetro triangolo t = " + t.perimetro());
		
		Forma q = new Quadrato(2);
		System.out.println("area quadrato q = " + q.area());
		System.out.println("perimetro quadrato q = " + q.perimetro());
		
		Forma c = new Cerchio(3);
		System.out.println("area cerchio c = " + c.area());
		System.out.println("perimetro cerchio c = " + c.perimetro());
	
		Forma c1 = new Cerchio(5);
		System.out.println("area cerchio c = " + c.area());
		System.out.println("perimetro cerchio c = " + c.perimetro());

		Forma c2 = new Cerchio(3);
		System.out.println("area cerchio c = " + c.area());
		System.out.println("perimetro cerchio c = " + c.perimetro());

		System.out.println("\n\nCiclo su array - collezione di forme");

		Forma[] collFigure = {t, q, c, c1};
		for(int i = 0; i < collFigure.length; i++) {
			System.out.println("Figura " + i + " calcolo:");
			System.out.println("area: " + collFigure[i].area());
			System.out.println("perimetro: " + collFigure[i].perimetro());
		}
		
		System.out.println("Confronto area e perimetro di c con c1 (diversi)");
		boolean bareac = c.compareArea(c1);
		boolean bperimc = c.comparePerim(c1);
		System.out.println(bareac + " " + bperimc);
		
		System.out.println("Confronto area e perimetro di c con c2 (uguali)");
		bareac = c.compareArea(c2);
		bperimc = c.comparePerim(c2);
		System.out.println(bareac + " " + bperimc);

		System.out.println("Confronto area e perimetro di c con t (diversi)");
		bareac = c.compareArea(t);
		bperimc = c.comparePerim(t);
		System.out.println(bareac + " " + bperimc);
		
		//quadrato q di l=2 area=4 perimetro=8
		Forma rett = new Rettangolo(4, 1); //area = 4, perimetro = 10
		System.out.println("Confronto area e perimetro di q con rett");
		bareac = q.compareArea(rett); //TRUE 
		bperimc = q.comparePerim(rett); //FALSE
		System.out.println(bareac + " " + bperimc);

		double d = 4.776784545345234; //scarpe
		int i = 9; //marmellata
		
		i = (int)d; //4
		System.out.println(i);

	}
}

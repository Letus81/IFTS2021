
public class Persona {
	//variabili di istanza perché non presenta static
	private String nome;
	private String cognome;
	private int eta;
	
	//variabile di classe
	static int mani;
	static int piedi;

	//costruttore senza parametri
	public Persona() {
		nome = "";
		cognome = "";
		eta = 0;
	}
	
	public Persona(String n, String c, int e) {
		nome = n;
		cognome = c;
		eta = e;
	}
	
	public void presenzazione() {
		System.out.println("Salve sono " + nome + " " + cognome);
	}
	
	public void cambiareNome(String n) {
		//condizioni
		nome = n;
	}
	
	public String restituisciNome() {
		//condizioni
		return nome;
	}
	
	public void cambiaCognome(String c) {
		cognome = c;
	}
	
	public String restituisciCognome() {
		return cognome;
	}
}

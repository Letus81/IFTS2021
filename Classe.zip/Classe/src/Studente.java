
public class Studente extends Persona {
	
	private String corso;
	
	public void iscrivere(String c) {
		corso = c;
	} 
	
	public void pianoStudi() {
		System.out.println(corso);
	}

}

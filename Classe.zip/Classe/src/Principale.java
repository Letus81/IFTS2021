
public class Principale {

	public static void main(String[] args) {
		Persona anto = new Persona("Antonio", "Lezzi", 39);
		anto.presenzazione();
		
		Persona pippo = new Persona("Pippo", "Pluto", 23);
		pippo.presenzazione();
		
		//nome è privato e quindi non è modificabile all'esterno
		//anto.nome = "Ciccio";
		anto.cambiareNome("Antonio Giovanni");
		
		anto.presenzazione();
		String n = anto.restituisciNome(); //Antonio Giovanni
		System.out.println(n);
		
		pippo.presenzazione();
		
		Persona.mani = 2;
		System.out.println("Stampo Persona.mani =" + Persona.mani); //2
		anto.mani = 5;
		System.out.println("Stampo anto.mani =" + anto.mani); //5
		System.out.println("Stampo pippo.mani =" + pippo.mani); //NO 2 -> 5!!
		
		
		Persona.piedi = 5;
		System.out.println("Stampo anto.piedi =" + anto.piedi); //5
		System.out.println("Stampo pippo.piedi =" + pippo.piedi); //5!!
		
		//alias, NON è una copia 
		Persona paperino = pippo;
		pippo = null;
		System.out.println("Stampo le info di paperino");
		paperino.presenzazione();
		System.out.println("cambio nome di paperino, attenzione è stesso oggetto di pippo");
		paperino.cambiareNome("Paperino");
		System.out.println("Stampo le info di pippo");
		//pippo.presenzazione();
		
		//
		paperino.presenzazione();
		
		
		String ciao = "ciao";
		String saluto = ciao;
		System.out.println(saluto);
		
		Studente studPippo = new Studente();
		studPippo.cambiaCognome("PPPPP");
		studPippo.cambiareNome("Studente PIPPO");
		studPippo.iscrivere("Java");
		studPippo.presenzazione(); //Salve sono Studente PIPPO PPPP
		studPippo.pianoStudi(); //java
	}

}

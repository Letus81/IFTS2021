import animale.Acqua;
import animale.Acquatici;
import animale.Anfibio;
import animale.Animale;
import animale.Terrestri;


//figure geometriche, trinagolo, quadrato, circonferenza -> perimetro e area
public class Principale {

	public static void main(String[] args) {
		//Animale anim1 = new Animale();		
		System.out.println("Adesso creo un pesce");
		Acquatici pescerosso = new Acquatici("pesce");
		pescerosso.respira();
		pescerosso.muovere();
		pescerosso.nuotare();
		
		System.out.println("Adesso creo un cane");
		Terrestri cane = new Terrestri("mammifero");
		cane.respira();
		cane.muovere();
		cane.cammina();
		
		System.out.println("Adesso creo una rana");
		Anfibio rana = new Anfibio("anfibio");
		rana.muovere();
		//rana.respiraAcqua();
		//rana.respiraTerra();
		//rana.respira("acqua");
		rana.respira("terra");
		
	}

}

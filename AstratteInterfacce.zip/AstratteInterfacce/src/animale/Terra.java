package animale;


public interface Terra {
	void respiraTerra();
}

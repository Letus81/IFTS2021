package animale;

public class Acquatici extends Animale {
	int pinne;
	
	public Acquatici(String s) {
		specie = s;
	}
	
	
	public void respira() {
		System.out.println("Animale acquatico respira in acqua");
	}
	
	public void nuotare() {
		System.out.println("nuota");
	}
}

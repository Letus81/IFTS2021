package animale;

//ASSOLUTAMENTE NO, in java si può estendere solo e soltanto una classe per volta
public class Anfibio extends Animale  {

	public Anfibio(String s) {
		specie = s;
	}
	
	public void respira(String ctx) {
		if (ctx.equals("acqua"))
			respiraAcqua();
		else if (ctx.equals("terra"))
			respiraTerra();
	}
	
	public void respiraAcqua() {
		System.out.println("Anfibio respira in acqua");
	}
	
	public void respiraTerra() {
		System.out.println("Anfibio respira usando aria");
		
	}

}

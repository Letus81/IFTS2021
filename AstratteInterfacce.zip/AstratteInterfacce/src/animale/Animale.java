package animale;

public abstract class Animale {
	protected String specie;
	
	//abstract void respira();
	
	public Animale() {
		specie = "";
	}
	
	//overloading del costruttore
	public Animale(String specie) {
		this.specie = specie;
	}
	
	public String getSpecie() {
		return specie;
	}
	
	public void muovere() {
		System.out.println("mi sto muovendo");
	}

}

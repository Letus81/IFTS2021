package animale;

public class Terrestri extends Animale {
	int zampe;
	
	public Terrestri(String s) {
		specie = s;
	}
	
	public void respira() {
		System.out.println("Animale terrestre respira aria");
	}
	
	public void cammina() {
		System.out.println("cammina");
	}

}

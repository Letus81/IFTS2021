package animale;

public interface Acqua {
	void respiraAcqua();
}

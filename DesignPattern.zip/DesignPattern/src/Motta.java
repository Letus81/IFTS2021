
public class Motta {
	
	public Alimento produci(String cosa) {
		Alimento a = null;
		
		if (cosa.equals("panettone"))
			a = new Panettone("PanettoneCioccolato", 3000);
		
		if (cosa.equals("pandoro"))
			a = new Pandoro("PanClassico", 4000);
		
		return a;
	}
}

public class Principale {
	public static void main(String[] args) {
		//Printer p = new Printer();
		//ERRORE Printer.stampa("ciao");

		//metodo di classe che crea la sola e unica istanza Printer
		Printer p = Printer.getInstance();
		p.stampa("ciao"); //96

		//alias?!
		Printer a = Printer.getInstance();
		if (p == a) //VERA
			System.out.println("Stesso oggetto");

		else
			System.out.println("Oggetti diversi");

		a.stampa("prova"); 
		//Stampanti sono diverse 95 = 100- 5
		//Stampanti sono uguali 91 = 96-5
		
		Alimento[] scatola = new Alimento[3];
		Motta m = new Motta();
		scatola[0] = m.produci("pandoro");
		scatola[1] = m.produci("panettone");
		scatola[2] = m.produci("pandoro");
		
		for(int i = 0; i < scatola.length; i++) {
			scatola[i].stampaInfo();
			
			if(scatola[i] instanceof Pandoro) {
				Pandoro pa = (Pandoro)scatola[i];
				System.out.println("zucchero: " + pa.getZuccheroVelo());
			}
			
			if(scatola[i] instanceof Panettone) {
				Panettone pa = (Panettone)scatola[i];
				System.out.println("uvetta: " + pa.getQtUvetta());
			}

		}
	}

}

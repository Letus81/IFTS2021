
public abstract class Alimento {
	String nome;
	int calorie;

	public Alimento() {
		nome = "";
		calorie = 0;
	}
	
	public Alimento(String n, int c) {
		nome = n;
		calorie = c;
	}
	
	public void stampaInfo() {
		System.out.println("nome: " + nome);
		System.out.println("calorie: " + calorie);
	}
}


//Design Pattern = Singleton, creare una e una sola istanza della classe
public class Printer {

	private static Printer s = null;
	
	int qtink = 100;
	
	
	private Printer() {
		System.out.println("Printer costruttore");
	}
	
	public static Printer getInstance() {
		System.out.println("Printer getInstance");
		
		if(s == null) //s non contiene nessuna istanza/oggetto
			s = new Printer();
		
		return s;
	}
	
	public void stampa(String s) {
		System.out.println("Printer stampa " + s);
		qtink -= s.length(); // qtink = qtink - s.length();
		System.out.println("quantità inchiostro " + qtink);
	}
}

public class Pandoro extends Alimento {
	private int zuccherovelo = 0;
	
	public Pandoro(String n, int c) {
		super(n, c);
		zuccherovelo = 100;
	}
	
	public void setZuccheroVelo(int v) {
		zuccherovelo = v;
	}
	
	public int getZuccheroVelo() {
		return zuccherovelo;
	}

}


public class Panettone extends Alimento {
	private int qtuvetta;

	public Panettone(String n, int c) {
		super(n, c);
		qtuvetta = 14;
	}
	
	public void setQtUvetta(int v) {
		qtuvetta = v;
	}
	
	public int getQtUvetta() {
		return qtuvetta;
	}


}
